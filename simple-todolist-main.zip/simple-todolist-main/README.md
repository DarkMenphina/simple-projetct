# Simple Todolist 
Simple Todolist made with HTML and CSS

## Screemshot
![Simple Todolist Screemshot](screemshot.png)
